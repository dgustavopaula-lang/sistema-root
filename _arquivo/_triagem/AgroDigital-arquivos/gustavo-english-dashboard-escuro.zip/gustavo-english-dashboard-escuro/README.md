# Gustavo English Dashboard — Tema Escuro

Projeto em HTML, CSS e JavaScript com fundo escuro como tema padrão.

## Como abrir

1. Extraia o arquivo ZIP.
2. Abra o VS Code.
3. Clique em **File > Open Folder**.
4. Escolha a pasta `gustavo-english-dashboard-escuro`.
5. Abra o arquivo `index.html` no navegador.

O botão **Alternar tema** permite mudar entre o tema escuro e o tema claro.
