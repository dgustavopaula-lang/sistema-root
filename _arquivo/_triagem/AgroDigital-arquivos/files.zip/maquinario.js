// maquinario.js
// Depende de uma variavel global `farmId` ja existente no script.js do AgroDigital

function mostrarFormularioMaquina() {
  const form = document.getElementById("form_maquina");
  form.style.display = form.style.display === "none" ? "block" : "none";
}

function alternarCamposAluguel() {
  const status = document.getElementById("maq_status").value;
  const campos = document.getElementById("campos_aluguel");
  campos.style.display = (status === "alugada" || status === "emprestada") ? "block" : "none";
}

async function salvarMaquina() {
  const payload = {
    nome: document.getElementById("maq_nome").value,
    fabricante: document.getElementById("maq_fabricante").value,
    modelo: document.getElementById("maq_modelo").value,
    status: document.getElementById("maq_status").value,
    valor_mensal: parseFloat(document.getElementById("maq_valor_mensal").value) || null,
    data_inicio: document.getElementById("maq_data_inicio").value || null,
    data_fim: document.getElementById("maq_data_fim").value || null,
  };

  const resp = await fetch(`/api/maquinario/${farmId}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!resp.ok) {
    const erro = await resp.json();
    alert("Erro ao salvar: " + (erro.erros || []).join(", "));
    return;
  }

  document.getElementById("form_maquina").style.display = "none";
  await carregarMaquinas();
}

async function carregarMaquinas() {
  const resp = await fetch(`/api/maquinario/${farmId}`);
  const maquinas = await resp.json();

  const lista = document.getElementById("lista_maquinas");
  lista.innerHTML = maquinas.map(m => `
    <div class="form-box">
      <strong>${m.nome}</strong> — ${m.fabricante.replace("_", " ")} ${m.modelo}
      <br>Status: ${m.status}
      ${m.valor_mensal ? `<br>R$ ${m.valor_mensal}/mes (${m.data_inicio} a ${m.data_fim})` : ""}
      <br><button onclick="removerMaquina('${m.id}')">Remover</button>
    </div>
  `).join("");

  await carregarResumoMaquinario();
}

async function removerMaquina(id) {
  await fetch(`/api/maquinario/item/${id}`, { method: "DELETE" });
  await carregarMaquinas();
}

async function carregarResumoMaquinario() {
  const resp = await fetch(`/api/maquinario/${farmId}/resumo`);
  const resumo = await resp.json();

  document.getElementById("maq_total").textContent = resumo.total;
  document.getElementById("maq_alugadas").textContent =
    resumo.por_status.alugada + resumo.por_status.emprestada;
  document.getElementById("maq_custo_mensal").textContent =
    `R$ ${resumo.custo_mensal_alugadas.toLocaleString("pt-BR")}`;
}

// Chamar ao entrar na secao de maquinario (ex: no listener de navegacao existente)
// carregarMaquinas();
