# routes/maquinario.py
# Modulo de Maquinario - AgroDigital
# CRUD de maquinas + controle de status (propria / alugada / emprestada)
# Fabricantes suportados no cadastro: Case IH, John Deere, Outro (generico)

from flask import Blueprint, request, jsonify
from datetime import datetime
import uuid

maquinario_bp = Blueprint("maquinario", __name__)

# --- Placeholder de "banco de dados" em memoria ---------------------------
# Troque por chamadas reais ao seu banco (mesmo padrao usado em
# services/deereTokenService.js: substitua db["maquinas"] por SELECT/INSERT).
db = {
    "maquinas": {}
}

FABRICANTES_VALIDOS = ["case_ih", "john_deere", "outro"]
STATUS_VALIDOS = ["propria", "alugada", "emprestada", "manutencao"]


def _validar_payload(payload):
    erros = []
    if not payload.get("nome"):
        erros.append("nome e obrigatorio")
    if payload.get("fabricante") not in FABRICANTES_VALIDOS:
        erros.append(f"fabricante deve ser um de {FABRICANTES_VALIDOS}")
    if payload.get("status") not in STATUS_VALIDOS:
        erros.append(f"status deve ser um de {STATUS_VALIDOS}")
    if payload.get("status") in ("alugada", "emprestada"):
        if not payload.get("data_inicio"):
            erros.append("data_inicio e obrigatoria para maquinas alugadas/emprestadas")
        if not payload.get("data_fim"):
            erros.append("data_fim e obrigatoria para maquinas alugadas/emprestadas")
    return erros


@maquinario_bp.route("/api/maquinario/<farm_id>", methods=["GET"])
def listar_maquinas(farm_id):
    maquinas = [
        m for m in db["maquinas"].values() if m["farm_id"] == farm_id
    ]
    return jsonify(maquinas), 200


@maquinario_bp.route("/api/maquinario/<farm_id>", methods=["POST"])
def criar_maquina(farm_id):
    payload = request.get_json(force=True) or {}
    erros = _validar_payload(payload)
    if erros:
        return jsonify({"erros": erros}), 400

    maquina_id = str(uuid.uuid4())
    maquina = {
        "id": maquina_id,
        "farm_id": farm_id,
        "nome": payload["nome"],
        "fabricante": payload["fabricante"],
        "modelo": payload.get("modelo", ""),
        "status": payload["status"],
        "valor_mensal": payload.get("valor_mensal"),
        "data_inicio": payload.get("data_inicio"),
        "data_fim": payload.get("data_fim"),
        "conectada_api": False,  # vira True quando integrada via OAuth (Deere/Case)
        "criada_em": datetime.utcnow().isoformat(),
    }
    db["maquinas"][maquina_id] = maquina
    return jsonify(maquina), 201


@maquinario_bp.route("/api/maquinario/item/<maquina_id>", methods=["PATCH"])
def atualizar_maquina(maquina_id):
    maquina = db["maquinas"].get(maquina_id)
    if not maquina:
        return jsonify({"erro": "maquina nao encontrada"}), 404

    payload = request.get_json(force=True) or {}
    campos_editaveis = [
        "nome", "modelo", "status", "valor_mensal", "data_inicio", "data_fim"
    ]
    for campo in campos_editaveis:
        if campo in payload:
            maquina[campo] = payload[campo]

    return jsonify(maquina), 200


@maquinario_bp.route("/api/maquinario/item/<maquina_id>", methods=["DELETE"])
def remover_maquina(maquina_id):
    if maquina_id not in db["maquinas"]:
        return jsonify({"erro": "maquina nao encontrada"}), 404
    del db["maquinas"][maquina_id]
    return jsonify({"removida": True}), 200


@maquinario_bp.route("/api/maquinario/<farm_id>/resumo", methods=["GET"])
def resumo_maquinario(farm_id):
    """Contagem por status - usado nos stat-cards do dashboard."""
    maquinas = [m for m in db["maquinas"].values() if m["farm_id"] == farm_id]
    resumo = {status: 0 for status in STATUS_VALIDOS}
    custo_mensal_alugadas = 0
    for m in maquinas:
        resumo[m["status"]] += 1
        if m["status"] in ("alugada", "emprestada") and m.get("valor_mensal"):
            custo_mensal_alugadas += m["valor_mensal"]

    return jsonify({
        "total": len(maquinas),
        "por_status": resumo,
        "custo_mensal_alugadas": custo_mensal_alugadas,
    }), 200


# --- Gancho para integracao futura com Deere/Case -------------------------
# Quando /auth/deere/connect (ja existente) autenticar a fazenda, marque
# maquina["conectada_api"] = True e passe a puxar dados reais via
# services/deereTokenService.js em vez do cadastro manual acima.
